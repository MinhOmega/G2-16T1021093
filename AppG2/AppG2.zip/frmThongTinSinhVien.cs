﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppG2
{
    public partial class frmThongTinSinhVien : Form
    {
        #region variables for process Image Avatar
        Image image;
        string pathDirectoryImg;
        string pathAvatarImg;
        #endregion
        public frmThongTinSinhVien()
        {
            InitializeComponent();
            pathDirectoryImg = Application.StartupPath + "/Img";
            pathAvatarImg = pathDirectoryImg + "/avatar.png";
            if (File.Exists(pathAvatarImg))
            {
                lnkChonAnhDaiDien.Image = Image.FromFile(pathAvatarImg);
            }
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void FrmThongTinSinhVien_Load(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void StatusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void LinkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Chọn ảnh đại diện";
            openFileDialog.Filter = "File ảnh|*.png;*.jpg"; //mô tả | định dạng
            if(openFileDialog.ShowDialog()== DialogResult.OK)
            {
                image = Image.FromFile(openFileDialog.FileName);
                lnkChonAnhDaiDien.Image = image;
                // từ đường dẫn openfIledialog.filename tạo ra 1 cái Image rồi gán lnkChonAnh vào image
            }
        }

        private void BtnCapNhat_Click(object sender, EventArgs e)
        {
            #region Cập nhật hình đại diện
            if(image!=null) // lưu ảnh vào thư mục cần
            {
                //đầu tiên phải thêm thư viện system.IO
                //string pathDirectory = Application.StartupPath + "/Img";// trả về thư mục chứa ứng dụng
                if (!Directory.Exists(pathDirectoryImg))
                {
                    Directory.CreateDirectory(pathDirectoryImg);
                }
                image.Save(pathDirectoryImg); // tạo tên file muốn lưu
            }
            #endregion
        }
    }
}
